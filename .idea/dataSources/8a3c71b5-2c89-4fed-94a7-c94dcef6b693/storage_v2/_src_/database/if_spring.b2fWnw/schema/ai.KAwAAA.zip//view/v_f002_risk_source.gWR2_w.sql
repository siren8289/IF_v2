create view v_f002_risk_source
            (source_table, source_record_key, source_period, dimension_name, metric_name, metric_value,
             source_endpoint) as
SELECT 'accident_age_stat'::text   AS source_table,
       accident_age_stat.id::text  AS source_record_key,
       accident_age_stat.source_period,
       accident_age_stat.age_group AS dimension_name,
       accident_age_stat.metric_name,
       accident_age_stat.metric_value,
       accident_age_stat.source_endpoint
FROM external_ref.accident_age_stat
UNION ALL
SELECT 'accident_industry_stat'::text         AS source_table,
       accident_industry_stat.id::text        AS source_record_key,
       accident_industry_stat.source_period,
       accident_industry_stat.industry_middle AS dimension_name,
       accident_industry_stat.metric_name,
       accident_industry_stat.metric_value,
       accident_industry_stat.source_endpoint
FROM external_ref.accident_industry_stat
UNION ALL
SELECT 'accident_size_stat'::text      AS source_table,
       accident_size_stat.id::text     AS source_record_key,
       accident_size_stat.source_period,
       accident_size_stat.company_size AS dimension_name,
       accident_size_stat.metric_name,
       accident_size_stat.metric_value,
       accident_size_stat.source_endpoint
FROM external_ref.accident_size_stat
UNION ALL
SELECT 'accident_labor_office_stat'::text      AS source_table,
       accident_labor_office_stat.id::text     AS source_record_key,
       accident_labor_office_stat.source_period,
       accident_labor_office_stat.labor_office AS dimension_name,
       accident_labor_office_stat.metric_name,
       accident_labor_office_stat.metric_value,
       accident_labor_office_stat.source_endpoint
FROM external_ref.accident_labor_office_stat;

alter table v_f002_risk_source
    owner to if_user;

