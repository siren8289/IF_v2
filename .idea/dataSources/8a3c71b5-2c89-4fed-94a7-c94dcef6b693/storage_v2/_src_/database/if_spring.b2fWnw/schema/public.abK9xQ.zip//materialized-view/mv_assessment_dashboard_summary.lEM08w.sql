create materialized view mv_assessment_dashboard_summary as
SELECT 1::smallint                                                   AS summary_id,
       count(*)                                                      AS total_count,
       count(*) FILTER (WHERE a.status::text = 'FINALIZED'::text)    AS finalized_count,
       count(*) FILTER (WHERE r.risk_grade::text = 'HIGH'::text)     AS high_risk_count,
       count(*) FILTER (WHERE a.status::text = 'PENDING_AI'::text)   AS pending_count,
       count(*) FILTER (WHERE a.status::text = 'AI_COMPLETED'::text) AS analyzed_count,
       max(a.assessed_at)                                            AS latest_assessed_at,
       now()                                                         AS refreshed_at
FROM assessment a
         LEFT JOIN ai_risk_result r ON r.ai_result_id = a.ai_result_id;

alter materialized view mv_assessment_dashboard_summary owner to if_user;

create unique index uk_mv_assessment_dashboard_summary
    on mv_assessment_dashboard_summary (summary_id);

