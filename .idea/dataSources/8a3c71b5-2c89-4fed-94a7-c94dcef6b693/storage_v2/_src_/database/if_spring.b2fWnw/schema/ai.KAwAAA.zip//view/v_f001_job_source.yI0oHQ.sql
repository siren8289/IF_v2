create view v_f001_job_source (source_table, source_record_key, job_title, raw_text, work_hours, workplace) as
SELECT 'public.job'::text AS source_table,
       job_id::text       AS source_record_key,
       job_title,
       description        AS raw_text,
       work_hours,
       workplace
FROM job j
WHERE NULLIF(TRIM(BOTH FROM description), ''::text) IS NOT NULL;

alter table v_f001_job_source
    owner to if_user;

