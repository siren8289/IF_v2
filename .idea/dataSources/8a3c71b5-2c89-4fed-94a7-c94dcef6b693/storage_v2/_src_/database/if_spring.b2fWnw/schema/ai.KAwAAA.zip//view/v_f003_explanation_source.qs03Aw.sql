create view v_f003_explanation_source
            (assessment_id, job_id, ai_result_id, risk_score, risk_grade, risk_model_version, explanation_json) as
SELECT a.assessment_id,
       a.job_id,
       r.ai_result_id,
       r.total_risk_percent AS risk_score,
       r.risk_grade,
       r.model_version      AS risk_model_version,
       r.explanation_json
FROM assessment a
         JOIN ai_risk_result r ON r.assessment_id = a.assessment_id
WHERE r.total_risk_percent IS NOT NULL
  AND r.risk_grade IS NOT NULL;

alter table v_f003_explanation_source
    owner to if_user;

